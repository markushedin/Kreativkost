<?php include("inc/header.php");?>

    <main class="container no-padding">
        <img src="/img/kavel.png" class="img-pa" alt="Dekorativ illustration i form av en kökskavel">
        <div class="recept" id="3">
            <!--Content will be here :)-->
        </div>
        <figure class="illustration-container">
            <img src="/img/kavelgrupp.png" class="img-pa2" alt="Dekorativ illustration i form av en kökskavel">
        </figure>
    </main>
    <?php
        include("inc/footer.php");
    ?>
    <script src="/js/script.js"></script>
    <script src="/js/getRecept.js" defer></script>
</body>
</html>